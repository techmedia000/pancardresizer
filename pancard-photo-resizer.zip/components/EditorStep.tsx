import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { DocType, Requirement } from '../types';
import { useLanguage } from '../LanguageContext';

// Icons for the control panel
const RotateLeftIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 15l-6-6m0 0l6-6m-6 6h12a6 6 0 010 12h-3" />
  </svg>
);

const RotateRightIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 15l6-6m0 0l-6-6m6 6h-12a6 6 0 000 12h3" />
  </svg>
);

const ResetIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h5M20 20v-5h-5M4 4l16 16" />
    </svg>
);


interface EditorStepProps {
  imageSrc: string;
  docType: DocType;
  requirements: Requirement;
}

const EditorStep: React.FC<EditorStepProps> = ({ imageSrc, docType, requirements }) => {
  const { t } = useLanguage();
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });

  const [isProcessing, setIsProcessing] = useState(false);
  const [cropBoxStyle, setCropBoxStyle] = useState<React.CSSProperties>({});

  const imgRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const aspectRatio = useMemo(() => requirements.widthCm / requirements.heightCm, [requirements]);

  useEffect(() => {
    const calculateAndSetCropBox = () => {
      if (containerRef.current) {
        const container = containerRef.current;
        const containerWidth = container.offsetWidth;
        const containerHeight = container.offsetHeight;
        const containerRatio = containerWidth / containerHeight;
        
        let width, height;
        if (containerRatio > aspectRatio) {
          height = containerHeight;
          width = height * aspectRatio;
        } else {
          width = containerWidth;
          height = width / aspectRatio;
        }

        setCropBoxStyle({
          width: `${width}px`,
          height: `${height}px`,
        });
      }
    };
    
    const timeoutId = setTimeout(calculateAndSetCropBox, 0);

    const observer = new ResizeObserver(calculateAndSetCropBox);
    const element = containerRef.current;
    if (element) {
      observer.observe(element);
    }
    
    return () => {
      clearTimeout(timeoutId);
      if (element) {
        observer.unobserve(element);
      }
    };
  }, [aspectRatio]);

  const handleReset = useCallback(() => {
    setBrightness(100);
    setContrast(100);
    setRotation(0);
    setScale(1);
    setPosition({ x: 0, y: 0 });
  }, []);
  
  // Reset all state when a new image is loaded
  useEffect(() => {
    handleReset();
  }, [imageSrc, handleReset]);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsPanning(true);
    setPanStart({
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    });
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isPanning || !containerRef.current || !imgRef.current) return;
    
    let newX = e.clientX - panStart.x;
    let newY = e.clientY - panStart.y;
    
    const container = containerRef.current;
    const img = imgRef.current;
    
    const scaledImgWidth = img.offsetWidth * scale;
    const scaledImgHeight = img.offsetHeight * scale;
    
    const maxX = Math.max(0, (scaledImgWidth - container.offsetWidth) / 2);
    const maxY = Math.max(0, (scaledImgHeight - container.offsetHeight) / 2);

    newX = Math.max(-maxX, Math.min(maxX, newX));
    newY = Math.max(-maxY, Math.min(maxY, newY));

    setPosition({ x: newX, y: newY });
  }, [isPanning, panStart, scale]);

  const handleMouseUp = useCallback(() => {
    setIsPanning(false);
  }, []);

  const handleMouseLeave = useCallback(() => {
    setIsPanning(false);
  }, []);

  useEffect(() => {
    if (isPanning) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isPanning, handleMouseMove, handleMouseUp]);


  const handleRotate = (angle: number) => {
    setRotation(r => (r + angle + 360) % 360);
  }

  const downloadImage = async () => {
    if (!imgRef.current || !containerRef.current) return;
    setIsProcessing(true);

    const image = imgRef.current;
    const container = containerRef.current;
    const { naturalWidth, naturalHeight } = image;

    let cropBoxPixelWidth, cropBoxPixelHeight;
    const containerRatio = container.offsetWidth / container.offsetHeight;
    if (containerRatio > aspectRatio) {
        cropBoxPixelHeight = container.offsetHeight;
        cropBoxPixelWidth = cropBoxPixelHeight * aspectRatio;
    } else {
        cropBoxPixelWidth = container.offsetWidth;
        cropBoxPixelHeight = cropBoxPixelWidth / aspectRatio;
    }

    const cropBoxX = (container.offsetWidth - cropBoxPixelWidth) / 2;
    const cropBoxY = (container.offsetHeight - cropBoxPixelHeight) / 2;

    const displayToNaturalRatio = naturalWidth / image.offsetWidth;

    const imgLeftInContainer = (container.offsetWidth - image.offsetWidth * scale) / 2 + position.x;
    const imgTopInContainer = (container.offsetHeight - image.offsetHeight * scale) / 2 + position.y;

    const cropXOnImg = cropBoxX - imgLeftInContainer;
    const cropYOnImg = cropBoxY - imgTopInContainer;

    const sx = (cropXOnImg / scale) * displayToNaturalRatio;
    const sy = (cropYOnImg / scale) * displayToNaturalRatio;
    const sw = (cropBoxPixelWidth / scale) * displayToNaturalRatio;
    const sh = (cropBoxPixelHeight / scale) * displayToNaturalRatio;
    
    let targetWidth = Math.round((requirements.widthCm / 2.54) * requirements.dpi);
    let targetHeight = Math.round((requirements.heightCm / 2.54) * requirements.dpi);
    
    const canvas = document.createElement('canvas');
    const isSideways = rotation === 90 || rotation === 270;
    canvas.width = isSideways ? targetHeight : targetWidth;
    canvas.height = isSideways ? targetWidth : targetHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) {
        setIsProcessing(false);
        return;
    }

    ctx.filter = `brightness(${brightness}%) contrast(${contrast}%)`;

    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(rotation * Math.PI / 180);
    
    ctx.drawImage(
      image,
      sx, sy, sw, sh,
      -targetWidth / 2, -targetHeight / 2, targetWidth, targetHeight
    );
    
    const getBlob = (quality: number): Promise<Blob> =>
      new Promise((resolve, reject) => {
        canvas.toBlob(
          (blob) => {
            if (blob) resolve(blob);
            else reject(new Error('Canvas to Blob failed'));
          },
          'image/jpeg',
          quality
        );
      });

    const targetSizeInBytes = requirements.maxSizeKb * 1024;
    let blob: Blob;

    try {
      const highQualityBlob = await getBlob(0.95);

      if (highQualityBlob.size <= targetSizeInBytes) {
        blob = highQualityBlob;
      } else {
        const lowQualityBlob = await getBlob(0.1);

        if (lowQualityBlob.size > targetSizeInBytes) {
          blob = lowQualityBlob;
          alert(
            `This image is very hard to compress. The smallest size we could get is ${Math.round(blob.size / 1024)}KB, which is over the ${requirements.maxSizeKb}KB limit. The file may be rejected.`
          );
        } else {
          let lowerBound = 0.1;
          let upperBound = 0.95;
          let bestBlob = lowQualityBlob;

          for (let i = 0; i < 10; i++) {
            const quality = (lowerBound + upperBound) / 2;
            const tempBlob = await getBlob(quality);
            if (tempBlob.size <= targetSizeInBytes) {
              bestBlob = tempBlob;
              lowerBound = quality;
            } else {
              upperBound = quality;
            }
          }
          blob = bestBlob;
        }
      }
    } catch (error) {
      console.error("Image processing error:", error);
      alert('An error occurred while processing the image.');
      setIsProcessing(false);
      return;
    }
    
    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = `${docType}_${Date.now()}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(objectUrl);
    
    setIsProcessing(false);
  };

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      {/* Image Preview */}
      <div 
        className="w-full lg:w-2/3 bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center p-2 relative select-none" 
        style={{ 
            height: '500px',
            cursor: isPanning ? 'grabbing' : 'grab',
        }}
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseLeave={handleMouseLeave}
      >
        <img
          ref={imgRef}
          src={imageSrc}
          alt="Preview"
          className="max-w-full max-h-full"
          style={{ 
            filter: `brightness(${brightness}%) contrast(${contrast}%)`,
            transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
            transition: isPanning ? 'none' : 'transform 0.1s ease',
            pointerEvents: 'none',
          }}
          crossOrigin="anonymous"
        />
        <div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
          style={{
            boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.5)',
            border: '2px solid white',
            ...cropBoxStyle,
          }}
        />
      </div>

      {/* Controls Panel */}
      <div className="w-full lg:w-1/3 flex flex-col space-y-6">
        {/* Adjustments */}
        <div className="p-4 border rounded-lg">
          <h3 className="text-lg font-semibold mb-3 text-gray-700">{t('adjustments')}</h3>
          <div className="space-y-4">
            <div>
              <label htmlFor="brightness" className="block text-sm font-medium text-gray-700">{t('brightness')}: {brightness}%</label>
              <input type="range" id="brightness" min="50" max="150" value={brightness} onChange={(e) => setBrightness(Number(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"/>
            </div>
            <div>
              <label htmlFor="contrast" className="block text-sm font-medium text-gray-700">{t('contrast')}: {contrast}%</label>
              <input type="range" id="contrast" min="50" max="150" value={contrast} onChange={(e) => setContrast(Number(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"/>
            </div>
            <div>
              <label htmlFor="zoom" className="block text-sm font-medium text-gray-700">{t('zoom')}: {Math.round(scale * 100)}%</label>
              <input type="range" id="zoom" min="1" max="3" step="0.1" value={scale} onChange={(e) => setScale(Number(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"/>
            </div>
          </div>
        </div>
        
        {/* Transform */}
        <div className="p-4 border rounded-lg">
            <h3 className="text-lg font-semibold mb-3 text-gray-700">{t('transform')}</h3>
            <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">{t('rotation')}: {rotation}°</span>
                <div className="flex space-x-2">
                    <button aria-label={t('rotateLeft')} onClick={() => handleRotate(-90)} className="p-2 bg-gray-200 rounded-md hover:bg-gray-300 transition-colors flex items-center"><RotateLeftIcon/></button>
                    <button aria-label={t('rotateRight')} onClick={() => handleRotate(90)} className="p-2 bg-gray-200 rounded-md hover:bg-gray-300 transition-colors flex items-center"><RotateRightIcon/></button>
                </div>
            </div>
        </div>

        {/* Actions */}
        <div className="space-y-3">
            <button
                onClick={handleReset}
                className="w-full bg-gray-500 text-white font-bold py-3 px-4 rounded-md hover:bg-gray-600 transition-colors duration-200 flex items-center justify-center"
            >
                <ResetIcon /> {t('reset')}
            </button>
            <button
                onClick={downloadImage}
                disabled={isProcessing}
                className="w-full bg-green-600 text-white font-bold py-3 px-4 rounded-md hover:bg-green-700 transition-colors duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
                {isProcessing ? t('processing') : t('downloadFile')}
            </button>
        </div>
      </div>
    </div>
  );
};

export default EditorStep;
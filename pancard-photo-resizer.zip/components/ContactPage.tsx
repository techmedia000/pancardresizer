
import React from 'react';
import { useLanguage } from '../LanguageContext';

const ContactPage: React.FC = () => {
  const { t } = useLanguage();
  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md">
      <h1 className="text-3xl font-bold text-gray-800 mb-4 border-b pb-2">{t('contactTitle')}</h1>
      <div className="space-y-6 text-gray-700">
        <p>
          {t('contactIntro1')}
        </p>
        <p>
          {t('contactIntro2')}
        </p>
        <div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">{t('emailUsTitle')}</h2>
          <p>
            {t('emailUsDesc')}
            <br />
            <a href="mailto:support@pancardphotoresizer.com" className="text-blue-600 hover:underline">support@pancardphotoresizer.com</a>
          </p>
        </div>
        <div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">{t('businessInquiriesTitle')}</h2>
          <p>
            {t('businessInquiriesDesc')}
            <br />
            <a href="mailto:business@pancardphotoresizer.com" className="text-blue-600 hover:underline">business@pancardphotoresizer.com</a>
          </p>
        </div>
        <p>
          {t('contactClosing')}
        </p>
      </div>
    </div>
  );
};

export default ContactPage;

import React from 'react';
import { useLanguage } from '../LanguageContext';

const PrivacyPolicyPage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md prose">
      <h1 className="text-3xl font-bold text-gray-800 mb-4 border-b pb-2">{t('privacyTitle')}</h1>
      <div className="space-y-4 text-gray-700">
        <p><strong>{t('lastUpdated')}</strong> [Date]</p>
        
        <p>
          {t('privacyIntro')}
        </p>
        
        <h2 className="text-xl font-semibold text-gray-800 pt-4">{t('p1Title')}</h2>
        <p>
          {t('p1Desc')}
        </p>
        
        <h2 className="text-xl font-semibold text-gray-800 pt-4">{t('p2Title')}</h2>
        <p>
         {t('p2Desc')}
        </p>
        
        <h2 className="text-xl font-semibold text-gray-800 pt-4">{t('p3Title')}</h2>
        <p>
          {t('p3Desc')}
        </p>

        <h2 className="text-xl font-semibold text-gray-800 pt-4">{t('p4Title')}</h2>
        <p>
          {t('p4Desc')}
        </p>
        
        <h2 className="text-xl font-semibold text-gray-800 pt-4">{t('p5Title')}</h2>
        <p>
          {t('p5Desc')}
        </p>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;


import React from 'react';
import { DocType } from '../types';
import { REQUIREMENTS } from '../constants';
import { useLanguage } from '../LanguageContext';

interface RequirementStepProps {
  docType: DocType;
  onDocTypeChange: (docType: DocType) => void;
}

const RequirementStep: React.FC<RequirementStepProps> = ({ docType, onDocTypeChange }) => {
  const { t } = useLanguage();

  const renderRequirement = (type: DocType.Photo | DocType.Signature) => {
    const req = REQUIREMENTS[type];
    if (!req) return null;
    return (
      <div className="text-sm text-gray-600">
        <p>{t('width')}: {req.widthCm} cm, {t('height')}: {req.heightCm} cm</p>
        <p>{t('maxSize')}: {req.maxSizeKb} KB, {t('dpi')}: {req.dpi}</p>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-800">{t('selectDocType')}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button
          onClick={() => onDocTypeChange(DocType.Photo)}
          className={`p-6 border-2 rounded-lg text-left transition-all duration-200 ${
            docType === DocType.Photo ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-500' : 'border-gray-300 hover:border-blue-400'
          }`}
        >
          <h3 className="font-bold text-lg text-gray-900">{t('photograph')}</h3>
          {renderRequirement(DocType.Photo)}
        </button>
        <button
          onClick={() => onDocTypeChange(DocType.Signature)}
          className={`p-6 border-2 rounded-lg text-left transition-all duration-200 ${
            docType === DocType.Signature ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-500' : 'border-gray-300 hover:border-blue-400'
          }`}
        >
          <h3 className="font-bold text-lg text-gray-900">{t('signature')}</h3>
          {renderRequirement(DocType.Signature)}
        </button>
      </div>
    </div>
  );
};

export default RequirementStep;

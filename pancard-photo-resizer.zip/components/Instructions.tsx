
import React from 'react';
import { useLanguage } from '../LanguageContext';

const Instructions: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mt-8">
      <h2 className="text-xl font-bold text-gray-800 mb-4 border-b pb-2">{t('instructionsTitle')}</h2>
      <ul className="list-disc list-inside space-y-2 text-gray-700">
        <li>{t('instruction1')}</li>
        <li>{t('instruction2')}</li>
        <li>{t('instruction3')}</li>
        <li>{t('instruction4')}</li>
        <li>{t('instruction5')}</li>
      </ul>
    </div>
  );
};

export default Instructions;


import React from 'react';
import { Step } from '../types';
import { useLanguage } from '../LanguageContext';

interface StepperProps {
  currentStep: Step;
}

const Stepper: React.FC<StepperProps> = ({ currentStep }) => {
  const { t } = useLanguage();
  
  const steps = [
    { id: Step.Upload, name: t('upload') },
    { id: Step.Requirement, name: t('requirement') },
    { id: Step.Editor, name: t('editor') },
  ];

  return (
    <nav className="flex items-center justify-start space-x-2 mb-6">
      {steps.map((step, index) => {
        const isActive = currentStep === step.id;
        const isCompleted = currentStep > step.id;
        return (
          <div key={step.id} className="flex items-center">
            <div
              className={`px-4 py-2 text-sm font-medium rounded-md ${
                isActive
                  ? 'bg-blue-600 text-white'
                  : isCompleted
                  ? 'bg-gray-200 text-gray-700'
                  : 'bg-gray-200 text-gray-500'
              }`}
            >
              {step.id}. {step.name}
            </div>
          </div>
        );
      })}
    </nav>
  );
};

export default Stepper;

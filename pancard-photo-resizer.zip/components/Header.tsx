import React from 'react';
import { useLanguage } from '../LanguageContext';
import { LogoIcon } from './Icons';

interface HeaderProps {
  onNavClick: (e: React.MouseEvent<HTMLAnchorElement>, hash: string) => void;
}

const Header: React.FC<HeaderProps> = ({ onNavClick }) => {
  const { t } = useLanguage();

  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-800 shadow-md">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0 flex items-center gap-2">
            <LogoIcon />
            <p className="text-2xl font-bold text-white">{t('panCardResizer')}</p>
          </div>
          <nav>
            <a 
              href="#" 
              onClick={(e) => onNavClick(e, '')}
              className="px-3 py-2 rounded-md text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-blue-800 focus:ring-white">
              {t('home')}
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
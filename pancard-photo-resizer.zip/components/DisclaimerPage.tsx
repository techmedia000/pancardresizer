
import React from 'react';
import { useLanguage } from '../LanguageContext';

const DisclaimerPage: React.FC = () => {
  const { t } = useLanguage();
  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md">
      <h1 className="text-3xl font-bold text-gray-800 mb-4 border-b pb-2">{t('disclaimerTitle')}</h1>
      <div className="space-y-4 text-gray-700">
        <p>
          {t('disclaimerIntro')}
        </p>

        <h2 className="text-xl font-semibold text-gray-800 pt-4">{t('d1Title')}</h2>
        <p>
          {t('d1Desc')}
        </p>

        <h2 className="text-xl font-semibold text-gray-800 pt-4">{t('d2Title')}</h2>
        <p>
          {t('d2Desc')}
        </p>

        <h2 className="text-xl font-semibold text-gray-800 pt-4">{t('d3Title')}</h2>
        <p>
          {t('d3Desc')}
        </p>

        <p>
          {t('d4')}
        </p>
      </div>
    </div>
  );
};

export default DisclaimerPage;

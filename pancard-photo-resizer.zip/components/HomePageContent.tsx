
import React from 'react';
import { useLanguage } from '../LanguageContext';

const HomePageContent: React.FC = () => {
  const { t } = useLanguage();

  return (
    <>
      <div className="bg-white p-6 rounded-lg shadow-md mt-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 border-b pb-2">{t('howToUseTitle')}</h2>
        <p className="text-gray-700 mb-6">
          {t('howToUseSubtitle')}
        </p>
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex-shrink-0 w-24 h-24 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-4xl font-bold">1</div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-800">{t('step1Title')}</h3>
              <p className="text-gray-600">{t('step1Desc')}</p>
            </div>
          </div>
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex-shrink-0 w-24 h-24 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-4xl font-bold">2</div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-800">{t('step2Title')}</h3>
              <p className="text-gray-600">{t('step2Desc')}</p>
            </div>
          </div>
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex-shrink-0 w-24 h-24 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-4xl font-bold">3</div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-800">{t('step3Title')}</h3>
              <p className="text-gray-600">{t('step3Desc')}</p>
            </div>
          </div>
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex-shrink-0 w-24 h-24 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-4xl font-bold">4</div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-800">{t('step4Title')}</h3>
              <p className="text-gray-600">{t('step4Desc')}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md mt-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 border-b pb-2">{t('whyUsTitle')}</h2>
        <p className="text-gray-700 mb-4">
          {t('whyUsSubtitle')}
        </p>
        <ul className="list-disc list-inside space-y-2 text-gray-700">
          <li><strong>{t('whyUsPoint1').split(':')[0]}:</strong> {t('whyUsPoint1').split(':').slice(1).join(':')}</li>
          <li><strong>{t('whyUsPoint2').split(':')[0]}:</strong> {t('whyUsPoint2').split(':').slice(1).join(':')}</li>
          <li><strong>{t('whyUsPoint3').split(':')[0]}:</strong> {t('whyUsPoint3').split(':').slice(1).join(':')}</li>
          <li><strong>{t('whyUsPoint4').split(':')[0]}:</strong> {t('whyUsPoint4').split(':').slice(1).join(':')}</li>
        </ul>
      </div>
    </>
  );
};

export default HomePageContent;


import React from 'react';
import { useLanguage, Language } from '../LanguageContext';

interface FooterProps {
  onNavClick: (e: React.MouseEvent<HTMLAnchorElement>, hash: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavClick }) => {
  const { language, setLanguage, t } = useLanguage();

  const handleLangClick = (e: React.MouseEvent<HTMLAnchorElement>, lang: Language) => {
    e.preventDefault();
    setLanguage(lang);
  };

  return (
    <footer className="bg-white py-4 mt-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-600">
        <div className="mb-2">
          <span>{t('changeLanguage')} </span>
          <a href="#" onClick={(e) => handleLangClick(e, 'en')} className={`text-blue-600 hover:underline ${language === 'en' ? 'font-bold' : ''}`}>{t('english')}</a> | 
          <a href="#" onClick={(e) => handleLangClick(e, 'hi')} className={`text-blue-600 hover:underline ${language === 'hi' ? 'font-bold' : ''}`}>{t('hindi')}</a>
        </div>
        <p className="text-sm">
          {t('copyright')} | 
          <a href="#contact" onClick={(e) => onNavClick(e, '#contact')} className="text-blue-600 hover:underline"> {t('contactUs')}</a> | 
          <a href="#privacy" onClick={(e) => onNavClick(e, '#privacy')} className="text-blue-600 hover:underline"> {t('privacyPolicy')}</a> |
          <a href="#disclaimer" onClick={(e) => onNavClick(e, '#disclaimer')} className="text-blue-600 hover:underline"> {t('disclaimer')}</a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;

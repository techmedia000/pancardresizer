
import React from 'react';
import { UnlimitedIcon, FastIcon, SecurityIcon, UserFriendlyIcon } from './Icons';
import { useLanguage } from '../LanguageContext';

const Features: React.FC = () => {
  const { t } = useLanguage();

  const features = [
    {
      icon: <UnlimitedIcon />,
      title: t('unlimitedTitle'),
      description: t('unlimitedDesc'),
    },
    {
      icon: <FastIcon />,
      title: t('fastTitle'),
      description: t('fastDesc'),
    },
    {
      icon: <SecurityIcon />,
      title: t('securityTitle'),
      description: t('securityDesc'),
    },
    {
      icon: <UserFriendlyIcon />,
      title: t('userFriendlyTitle'),
      description: t('userFriendlyDesc'),
    },
  ];

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mt-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {features.map((feature, index) => (
          <div key={index} className="text-center">
            <div className="flex justify-center mb-4">
              {feature.icon}
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
            <p className="text-gray-600 text-sm">{feature.description}</p>
          </div>
        ))}
      </div>
      <div className="border-t mt-8 pt-4">
        <p className="text-sm text-gray-500 text-center">
          {t('featuresFooter')}
        </p>
      </div>
    </div>
  );
};

export default Features;
